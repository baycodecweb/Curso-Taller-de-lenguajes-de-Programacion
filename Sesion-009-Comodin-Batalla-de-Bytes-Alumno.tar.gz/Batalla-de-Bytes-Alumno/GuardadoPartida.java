import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 * Sesion 5 - Manejo de Archivos de Texto y Excepciones.
 * Guarda y carga el progreso del entrenador en un archivo de texto
 * plano y legible (mismo enfoque que el "Módulo de Registro en Texto
 * Plano" de la Sesión 5), para poder seguir la partida otro día.
 *
 * Formato del archivo (una línea por dato):
 *   nombre;criaturaActiva;pociones;victorias
 *
 * TODO Sesión 5 (avanzado, opcional) — ¡Te toca a ti!
 * Ahora mismo solo se guarda LA CRIATURA ACTIVA del entrenador, no todo
 * su equipo. Para guardar un equipo completo (por ejemplo, si Entrenador
 * tuviera una lista de varias Criatura en vez de una sola) necesitarías:
 *   1. Cambiar Entrenador para que tenga una lista de criaturas.
 *   2. Cambiar el formato del archivo para poder guardar varias líneas
 *      (una por criatura) o separarlas con otro caracter, ej. "|".
 *   3. Actualizar guardar() y cargar() para leer/escribir esa lista.
 * No es obligatorio tocar código aquí para este ejercicio: la idea es
 * que lo diseñes en papel o lo intentes si quieres el reto completo.
 */
public class GuardadoPartida {

    public static void guardar(Entrenador entrenador, String archivo) throws IOException {
        try (FileWriter writer = new FileWriter(archivo)) {
            String linea = String.join(";",
                    entrenador.getNombre(),
                    entrenador.getCriaturaActiva().getNombre(),
                    String.valueOf(entrenador.getPociones()),
                    String.valueOf(entrenador.getVictorias()));
            writer.write(linea);
        }
    }

    /** Devuelve null si el archivo todavía no existe (primera vez que se juega). */
    public static Entrenador cargar(String archivo) throws IOException {
        try (BufferedReader lector = new BufferedReader(new FileReader(archivo))) {
            String linea = lector.readLine();
            if (linea == null) {
                throw new IOException("El archivo de guardado está vacío o dañado.");
            }
            String[] partes = linea.split(";");
            if (partes.length != 4) {
                throw new IOException("Formato de guardado inválido: " + linea);
            }

            String nombre = partes[0];
            Criatura criatura = FabricaCriaturas.crearPorNombre(partes[1]);
            int pociones = Integer.parseInt(partes[2]);
            int victorias = Integer.parseInt(partes[3]);

            Entrenador entrenador = new Entrenador(nombre, criatura);
            entrenador.setPociones(pociones);
            entrenador.setVictorias(victorias);
            return entrenador;
        }
    }
}
