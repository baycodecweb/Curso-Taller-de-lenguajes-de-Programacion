# Batalla de Bytes (versión para alumnos)

Juego de batallas de criaturas (estilo Pokémon) construido **solo** con lo
que enseña el Taller de Lenguajes de Programación: Swing, POO, archivos,
excepciones, SQL/MySQL, JDBC y Servlets. Un mismo proyecto que crece
sesión a sesión, probado y funcionando de punta a punta.

> **Esta versión tiene 8 ejercicios `// TODO` (uno por sesión) que debes**
> **completar.** Empieza por **`GUIA-PARA-ALUMNOS.md`**, no por este
> archivo — ahí está la lista completa con pistas y el orden recomendado.
> Este README es la referencia del proyecto ya funcionando tal como lo
> recibiste (sin los ejercicios resueltos todavía).

## Qué archivo corresponde a cada sesión

| Sesión | Archivo(s) | Qué demuestra |
|---|---|---|
| 1 – Swing y eventos | `PantallaInicio.java` | `JButton` + `ActionListener` para elegir criatura |
| 2 – Layouts avanzados | `PantallaBatalla.java` | `BorderLayout`, `GridLayout`, `JProgressBar` |
| 3 – Polimorfismo/abstractas | `Ataque.java` (abstracta) + `AtaqueFuego`, `AtaqueAgua`, `AtaquePlanta`, `AtaqueNeutral` | Cada subclase calcula su propio multiplicador de daño |
| 4 – UML/constructores/`this` | `Criatura.java` (con el diagrama UML en el comentario) | Constructor usando `this` |
| 5 – Archivos/excepciones | `GuardadoPartida.java`, `SinPocionesException.java` | Guardar/cargar partida en texto plano; excepción personalizada |
| 6 – SQL/MySQL | `batalla_bytes_db.sql` | Diseño de la tabla `entrenadores` |
| 7 – JDBC | `ConexionBD.java`, `EntrenadorDAO.java` | `PreparedStatement`, ranking en MySQL |
| 8 – Servlets | `RankingServlet.java`, `MainRankingWeb.java` | Página web con el mismo ranking, sin instalar nada aparte |
| Proyecto Final | `BatallaDeBytes.java` (arranca todo) | Todo integrado |

## 1. Jugar el juego de escritorio (no necesita MySQL)

```bash
cd Batalla-de-Bytes-Alumno
javac -cp "../lib/*" *.java
java BatallaDeBytes
```

Elige tu criatura (Flamito 🔥, Marina 💧 o Hojaverde 🌿), pelea contra un
rival aleatorio, usa pociones y guarda tu partida en `partida.txt`.
El triángulo de tipos: Fuego > Planta > Agua > Fuego.

## 2. Activar el ranking del salón (MySQL + JDBC)

1. Crea la base de datos (usa el mismo MySQL que ya tienes corriendo
   para `gamestore_db`):
   ```bash
   mysql -u root -p < batalla_bytes_db.sql
   ```
2. Revisa `ConexionBD.java`: usa las mismas credenciales que
   `../codigo3/ConexionBD.java` (cámbialas si tu MySQL es distinto).
3. Ejecuta el juego con el conector de MySQL en el classpath:
   ```bash
   java -cp ".:../lib/*" BatallaDeBytes
   ```
4. Gana una batalla y presiona **"Guardar en ranking del salón"**.

## 3. Ver el ranking desde el navegador (Servlet + Tomcat embebido)

```bash
java -cp ".:../lib/*" MainRankingWeb
```

Abre `http://localhost:8081/ranking` — verás la misma tabla `entrenadores`
que llenó el juego de escritorio, en vivo.

## Probado

Todo el flujo se probó de punta a punta en este entorno: compilación,
batalla completa con daño y multiplicadores de tipo correctos, poción,
guardado en archivo, guardado en MySQL vía JDBC, y la página web del
ranking sirviendo los datos reales desde el servlet.

## Posibles extensiones (para ir más allá)

- Más criaturas y ataques (agregar una 4ª/5ª subclase de `Ataque`).
- Subir de nivel tras cada victoria (aumentar `vidaMaxima`).
- Guardado binario con `ObjectOutputStream` en vez de texto plano.
- Un `LoginServlet` para que cada alumno inicie sesión antes de ver
  su propio historial (reutilizando el patrón de `GameStoreLoginServletIntegrado`).
