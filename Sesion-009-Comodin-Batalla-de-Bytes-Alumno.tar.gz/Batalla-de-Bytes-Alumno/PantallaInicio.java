import javax.swing.*;
import java.awt.*;
import java.io.IOException;

/**
 * Sesion 1 - Programación Orientada a Eventos y Componentes Gráficos Básicos.
 * Pantalla de inicio: el jugador escribe su nombre y elige una de las
 * 3 criaturas iniciales (cada botón dispara un ActionListener, igual
 * que el patrón "Ingresar" del GameStoreLogin de la Sesión 1).
 */
public class PantallaInicio extends JFrame {

    private final JTextField txtNombre;

    public PantallaInicio() {
        setTitle("Batalla de Bytes - Elige tu criatura");
        setSize(420, 320);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        JLabel titulo = new JLabel("★ BATALLA DE BYTES ★", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 20));
        titulo.setForeground(new Color(2, 132, 199));
        titulo.setBorder(BorderFactory.createEmptyBorder(15, 10, 5, 10));
        add(titulo, BorderLayout.NORTH);

        JPanel centro = new JPanel();
        centro.setLayout(new BoxLayout(centro, BoxLayout.Y_AXIS));
        centro.setBorder(BorderFactory.createEmptyBorder(5, 30, 5, 30));

        JPanel filaNombre = new JPanel(new FlowLayout(FlowLayout.LEFT));
        filaNombre.add(new JLabel("Nombre de entrenador:"));
        txtNombre = new JTextField(14);
        filaNombre.add(txtNombre);
        centro.add(filaNombre);

        JLabel elige = new JLabel("Elige tu criatura inicial:");
        elige.setAlignmentX(Component.CENTER_ALIGNMENT);
        elige.setBorder(BorderFactory.createEmptyBorder(10, 0, 5, 0));
        centro.add(elige);

        // TODO Sesión 1 (Swing y Eventos) — ¡Te toca a ti!
        // Agrega un 4° botón para la criatura "Rocko" (TipoCriatura.TIERRA),
        // usando crearBotonCriatura(...) igual que los otros tres.
        // Pistas:
        //   1. Cambia el GridLayout(1, 3, ...) de abajo a GridLayout(1, 4, ...)
        //      para que el nuevo botón entre en la fila (esto es lo que
        //      trabajaste en la Sesión 2 sobre layouts).
        //   2. Agrega la línea filaCriaturas.add(crearBotonCriatura(...)).
        //   3. No funcionará del todo hasta que también completes
        //      FabricaCriaturas.crearRocko() (TODO Sesión 4) y
        //      AtaqueTierra.java (TODO Sesión 3).
        JPanel filaCriaturas = new JPanel(new GridLayout(1, 3, 10, 0));
        filaCriaturas.add(crearBotonCriatura("Flamito", "Flamito", TipoCriatura.FUEGO));
        filaCriaturas.add(crearBotonCriatura("Marina", "Marina", TipoCriatura.AGUA));
        filaCriaturas.add(crearBotonCriatura("Hojaverde", "Hojaverde", TipoCriatura.PLANTA));
        centro.add(filaCriaturas);

        add(centro, BorderLayout.CENTER);

        JButton btnCargar = new JButton("Cargar partida guardada");
        btnCargar.addActionListener(e -> cargarPartida());
        JPanel sur = new JPanel(new FlowLayout(FlowLayout.CENTER));
        sur.add(btnCargar);
        add(sur, BorderLayout.SOUTH);
    }

    private JButton crearBotonCriatura(String etiqueta, String nombreCriatura, TipoCriatura tipo) {
        JButton boton = new JButton("<html><div style='text-align:center;'>"
                + "<span style='font-size:16px;'>" + IconosTipo.icono(tipo) + "</span><br>"
                + "<b>" + etiqueta + "</b></div></html>");
        boton.setForeground(IconosTipo.color(tipo));
        boton.setFont(boton.getFont().deriveFont(Font.PLAIN, 13f));
        boton.addActionListener(e -> comenzarAventura(nombreCriatura));
        return boton;
    }

    private void comenzarAventura(String nombreCriatura) {
        String nombreEntrenador = txtNombre.getText().trim();
        if (nombreEntrenador.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Escribe primero tu nombre de entrenador.",
                    "Falta el nombre", JOptionPane.WARNING_MESSAGE);
            return;
        }

        Criatura criatura = FabricaCriaturas.crearPorNombre(nombreCriatura);
        Entrenador entrenador = new Entrenador(nombreEntrenador, criatura);

        new PantallaBatalla(entrenador).setVisible(true);
        dispose();
    }

    private void cargarPartida() {
        try {
            Entrenador entrenador = GuardadoPartida.cargar("partida.txt");
            new PantallaBatalla(entrenador).setVisible(true);
            dispose();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this,
                    "No se pudo cargar la partida (" + e.getMessage() + ").\n"
                            + "Elige una criatura para empezar una nueva.",
                    "Sin partida guardada", JOptionPane.INFORMATION_MESSAGE);
        }
    }
}
