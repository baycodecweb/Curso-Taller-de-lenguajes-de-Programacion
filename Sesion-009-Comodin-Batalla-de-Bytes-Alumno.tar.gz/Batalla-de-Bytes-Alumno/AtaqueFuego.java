/** Ataque elemental de tipo FUEGO: fuerte contra PLANTA, débil contra AGUA. */
public class AtaqueFuego extends Ataque {

    public AtaqueFuego(String nombre, int poderBase) {
        super(nombre, poderBase);
    }

    @Override
    protected double calcularMultiplicador(TipoCriatura tipoRival) {
        if (tipoRival == TipoCriatura.PLANTA) return 1.5;
        if (tipoRival == TipoCriatura.AGUA) return 0.5;
        return 1.0;
    }
}
