/**
 * El jugador humano. Guarda su criatura activa, cuántas pociones le
 * quedan y cuántas batallas ha ganado (esto último es lo que luego
 * viaja a MySQL para el ranking del salón, Sesión 6-7).
 */
public class Entrenador {

    private final String nombre;
    private Criatura criaturaActiva;
    private int pociones;
    private int victorias;

    public Entrenador(String nombre, Criatura criaturaActiva) {
        this.nombre = nombre;
        this.criaturaActiva = criaturaActiva;
        this.pociones = 2;
        this.victorias = 0;
    }

    /** Cura 20 HP a la criatura activa, o lanza SinPocionesException si no quedan pociones. */
    public void usarPocion() throws SinPocionesException {
        if (pociones <= 0) {
            throw new SinPocionesException(nombre + " no tiene pociones restantes.");
        }
        pociones--;
        criaturaActiva.curar(20);
    }

    public void registrarVictoria() {
        victorias++;
    }

    public String getNombre() {
        return nombre;
    }

    public Criatura getCriaturaActiva() {
        return criaturaActiva;
    }

    public void setCriaturaActiva(Criatura criaturaActiva) {
        this.criaturaActiva = criaturaActiva;
    }

    public int getPociones() {
        return pociones;
    }

    public void setPociones(int pociones) {
        this.pociones = pociones;
    }

    public int getVictorias() {
        return victorias;
    }

    public void setVictorias(int victorias) {
        this.victorias = victorias;
    }
}
