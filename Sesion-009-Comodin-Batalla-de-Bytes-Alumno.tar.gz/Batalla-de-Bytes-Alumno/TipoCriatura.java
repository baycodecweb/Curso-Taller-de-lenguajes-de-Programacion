/**
 * Tipos de criatura disponibles en Batalla de Bytes.
 * Triángulo de ventajas (igual que en los juegos de criaturas clásicos):
 * FUEGO vence a PLANTA, PLANTA vence a AGUA, AGUA vence a FUEGO.
 *
 * TIERRA ya está agregado aquí para que puedas usarlo: tu trabajo (ver
 * TODO-Sesion3 en AtaqueTierra.java) es crear el ataque que le da su
 * fuerza/debilidad, no tocar este enum.
 */
public enum TipoCriatura {
    FUEGO,
    AGUA,
    PLANTA,
    TIERRA
}
