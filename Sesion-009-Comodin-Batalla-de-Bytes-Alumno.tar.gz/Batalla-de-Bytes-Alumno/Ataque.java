/**
 * Sesion 3 - Clases Abstractas y Polimorfismo.
 *
 * Ataque es el "molde" de todo movimiento que una Criatura puede usar.
 * Cada subclase decide, a su manera, cuanto daño real hace un ataque
 * cuando se ejecuta contra un rival (sobrescribiendo calcularMultiplicador).
 * Esto es polimorfismo real: el código que llama a ejecutar(...) no
 * necesita saber de qué tipo es el ataque, Java decide solo qué versión
 * de calcularMultiplicador() usar en tiempo de ejecución.
 */
public abstract class Ataque {

    private final String nombre;
    private final int poderBase;

    public Ataque(String nombre, int poderBase) {
        this.nombre = nombre;
        this.poderBase = poderBase;
    }

    public String getNombre() {
        return nombre;
    }

    public int getPoderBase() {
        return poderBase;
    }

    /** Cada subclase decide si es fuerte, débil o neutral contra el tipo rival. */
    protected abstract double calcularMultiplicador(TipoCriatura tipoRival);

    /**
     * Ejecuta el ataque de "atacante" contra "defensor" y devuelve un
     * mensaje listo para mostrar en el log de batalla.
     */
    public String ejecutar(Criatura atacante, Criatura defensor) {
        double multiplicador = calcularMultiplicador(defensor.getTipo());
        int danio = (int) Math.round(poderBase * multiplicador);
        defensor.recibirDanio(danio);

        String efecto;
        if (multiplicador > 1.0) {
            efecto = "¡Es muy efectivo!";
        } else if (multiplicador < 1.0) {
            efecto = "No es muy efectivo...";
        } else {
            efecto = "";
        }

        return String.format("%s usó %s -> %d de daño a %s. %s",
                atacante.getNombre(), nombre, danio, defensor.getNombre(), efecto).trim();
    }
}
