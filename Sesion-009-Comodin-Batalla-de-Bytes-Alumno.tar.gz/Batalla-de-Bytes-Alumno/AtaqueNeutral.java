/** Ataque sin tipo (ni fuerte ni débil contra nadie): multiplicador siempre 1.0. */
public class AtaqueNeutral extends Ataque {

    public AtaqueNeutral(String nombre, int poderBase) {
        super(nombre, poderBase);
    }

    @Override
    protected double calcularMultiplicador(TipoCriatura tipoRival) {
        return 1.0;
    }
}
