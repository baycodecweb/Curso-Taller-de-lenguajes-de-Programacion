import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.util.Random;

/**
 * Sesion 2 - Contenedores Avanzados y Administradores de Diseño (Layouts).
 * Pantalla de batalla: barras de vida con JProgressBar, grilla de
 * ataques con GridLayout, y un JTextArea como "log" de la pelea.
 *
 * También conecta con la Sesión 5 (guardar partida / SinPocionesException)
 * y con la Sesión 6-7 (guardar el resultado en el ranking de MySQL).
 */
public class PantallaBatalla extends JFrame {

    private final Entrenador entrenador;
    private final Criatura rival;
    private final Random azar = new Random();

    private final JProgressBar barraJugador;
    private final JProgressBar barraRival;
    private final JLabel etiquetaJugador;
    private final JLabel etiquetaRival;
    private final JTextArea log;
    private final JButton[] botonesAtaque = new JButton[4];
    private final JButton btnPocion;
    private boolean batallaTerminada = false;

    public PantallaBatalla(Entrenador entrenador) {
        this.entrenador = entrenador;
        this.rival = elegirRival(entrenador.getCriaturaActiva());

        setTitle("Batalla de Bytes - " + entrenador.getNombre());
        setSize(560, 520);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(8, 8));

        JPanel panelEstado = new JPanel(new GridLayout(2, 1, 4, 4));
        panelEstado.setBorder(BorderFactory.createEmptyBorder(10, 14, 10, 14));

        etiquetaJugador = new JLabel();
        barraJugador = new JProgressBar(0, entrenador.getCriaturaActiva().getVidaMaxima());
        barraJugador.setForeground(new Color(34, 197, 94));
        JPanel filaJugador = new JPanel(new BorderLayout());
        filaJugador.add(etiquetaJugador, BorderLayout.NORTH);
        filaJugador.add(barraJugador, BorderLayout.CENTER);

        etiquetaRival = new JLabel();
        barraRival = new JProgressBar(0, rival.getVidaMaxima());
        barraRival.setForeground(new Color(239, 68, 68));
        JPanel filaRival = new JPanel(new BorderLayout());
        filaRival.add(etiquetaRival, BorderLayout.NORTH);
        filaRival.add(barraRival, BorderLayout.CENTER);

        panelEstado.add(filaJugador);
        panelEstado.add(filaRival);
        add(panelEstado, BorderLayout.NORTH);

        log = new JTextArea();
        log.setEditable(false);
        log.setLineWrap(true);
        log.setWrapStyleWord(true);
        add(new JScrollPane(log), BorderLayout.CENTER);

        JPanel panelInferior = new JPanel(new BorderLayout(6, 6));
        JPanel grillaAtaques = new JPanel(new GridLayout(2, 2, 6, 6));
        Ataque[] ataques = entrenador.getCriaturaActiva().getAtaques();
        for (int i = 0; i < botonesAtaque.length; i++) {
            final int indice = i;
            botonesAtaque[i] = new JButton(iconoAtaque(ataques[i]) + " " + ataques[i].getNombre());
            botonesAtaque[i].setForeground(colorAtaque(ataques[i]));
            botonesAtaque[i].setFont(botonesAtaque[i].getFont().deriveFont(Font.BOLD));
            botonesAtaque[i].addActionListener(e -> turnoJugador(indice));
            grillaAtaques.add(botonesAtaque[i]);
        }
        panelInferior.add(grillaAtaques, BorderLayout.CENTER);

        btnPocion = new JButton("✚ Usar poción");
        btnPocion.addActionListener(e -> usarPocion());

        JButton btnGuardar = new JButton("▤ Guardar partida");
        btnGuardar.addActionListener(e -> guardarPartida());

        JButton btnRanking = new JButton("♛ Guardar en ranking del salón");
        btnRanking.addActionListener(e -> guardarEnRanking());

        // TODO Sesión 2 (Layouts avanzados) — ¡Te toca a ti!
        // Agrega un 4° botón "Huir" a esta fila, que llame a huirDeBatalla()
        // (el método ya existe más abajo, con su propio TODO).
        // Pista: si agregas el botón tal cual, sin cambiar nada más, el
        // GridLayout(1, 3, ...) de abajo va a "apretar" los 4 botones en
        // 3 columnas. Decide tú: ¿cambias a GridLayout(1, 4, ...), o
        // prefieres moverlo a una fila aparte con FlowLayout?
        JPanel filaAcciones = new JPanel(new GridLayout(1, 3, 6, 0));
        filaAcciones.add(btnPocion);
        filaAcciones.add(btnGuardar);
        filaAcciones.add(btnRanking);
        panelInferior.add(filaAcciones, BorderLayout.SOUTH);

        add(panelInferior, BorderLayout.SOUTH);

        actualizarEstado();
        agregarLog("¡Un " + rival.getNombre() + " salvaje apareció! Elige un ataque.");
    }

    /** Ícono según el tipo real del ataque (para pintar los botones de colores). */
    private String iconoAtaque(Ataque ataque) {
        if (ataque instanceof AtaqueFuego) return IconosTipo.icono(TipoCriatura.FUEGO);
        if (ataque instanceof AtaqueAgua) return IconosTipo.icono(TipoCriatura.AGUA);
        if (ataque instanceof AtaquePlanta) return IconosTipo.icono(TipoCriatura.PLANTA);
        return "●";
    }

    private Color colorAtaque(Ataque ataque) {
        if (ataque instanceof AtaqueFuego) return IconosTipo.color(TipoCriatura.FUEGO);
        if (ataque instanceof AtaqueAgua) return IconosTipo.color(TipoCriatura.AGUA);
        if (ataque instanceof AtaquePlanta) return IconosTipo.color(TipoCriatura.PLANTA);
        return Color.DARK_GRAY;
    }

    private Criatura elegirRival(Criatura propia) {
        String[] nombres = {"Flamito", "Marina", "Hojaverde"};
        String elegido;
        do {
            elegido = nombres[azar.nextInt(nombres.length)];
        } while (elegido.equals(propia.getNombre()));
        return FabricaCriaturas.crearPorNombre(elegido);
    }

    private void turnoJugador(int indiceAtaque) {
        if (batallaTerminada) {
            return;
        }
        Ataque ataque = entrenador.getCriaturaActiva().getAtaques()[indiceAtaque];
        agregarLog(ataque.ejecutar(entrenador.getCriaturaActiva(), rival));
        actualizarEstado();

        if (rival.estaDebilitada()) {
            terminarBatalla(true);
            return;
        }

        turnoRival();
    }

    private void turnoRival() {
        Ataque[] ataquesRival = rival.getAtaques();
        Ataque ataque = ataquesRival[azar.nextInt(ataquesRival.length)];
        agregarLog(ataque.ejecutar(rival, entrenador.getCriaturaActiva()));
        actualizarEstado();

        if (entrenador.getCriaturaActiva().estaDebilitada()) {
            terminarBatalla(false);
        }
    }

    /**
     * TODO Sesión 2 (Layouts avanzados) — ¡Te toca a ti!
     * Debe terminar la batalla sin contar como victoria ni como derrota:
     * simplemente cierra esta ventana (dispose()) y no llames a
     * entrenador.registrarVictoria(). Pista: mira cómo terminarBatalla()
     * deshabilita los botones de ataque; puedes reutilizar esa idea.
     */
    private void huirDeBatalla() {
        // TODO: implementa el "huir" (por ahora no hace nada)
    }

    private void usarPocion() {
        try {
            entrenador.usarPocion();
            agregarLog(entrenador.getNombre() + " usó una poción. " + entrenador.getCriaturaActiva().getNombre()
                    + " recuperó 20 HP. Pociones restantes: " + entrenador.getPociones());
            actualizarEstado();
        } catch (SinPocionesException ex) {
            agregarLog("⚠ " + ex.getMessage());
        }
    }

    private void terminarBatalla(boolean gano) {
        batallaTerminada = true;
        for (JButton boton : botonesAtaque) {
            boton.setEnabled(false);
        }
        if (gano) {
            entrenador.registrarVictoria();
            // TODO Sesión 4 (UML, Constructores y "this") — ¡Te toca a ti!
            // Descomenta la siguiente línea una vez que hayas completado
            // Criatura.ganarExperiencia(int) (ver TODO en Criatura.java).
            // entrenador.getCriaturaActiva().ganarExperiencia(30);
            agregarLog("★ ¡" + rival.getNombre() + " fue debilitado! " + entrenador.getNombre()
                    + " ganó la batalla. Victorias totales: " + entrenador.getVictorias());
            mostrarResultado(true);
        } else {
            agregarLog("☹ " + entrenador.getCriaturaActiva().getNombre() + " fue debilitado. Perdiste la batalla.");
            mostrarResultado(false);
        }
    }

    /** Ventanita grande y llamativa al terminar la batalla (más divertido que solo el log). */
    private void mostrarResultado(boolean gano) {
        String cara = gano ? "☺" : "☹";
        String titulo = gano ? "¡Victoria!" : "Derrota";
        String mensaje = gano
                ? entrenador.getNombre() + " ganó con " + entrenador.getCriaturaActiva().getNombre() + "!"
                : entrenador.getCriaturaActiva().getNombre() + " fue debilitado. ¡Inténtalo de nuevo!";
        String colorHex = gano ? "#16a34a" : "#dc2626";

        JOptionPane.showMessageDialog(this,
                "<html><div style='text-align:center;'>"
                        + "<font size='7' color='" + colorHex + "'>" + cara + "</font><br>"
                        + "<b>" + mensaje + "</b></div></html>",
                titulo, JOptionPane.PLAIN_MESSAGE);
    }

    private void guardarPartida() {
        try {
            GuardadoPartida.guardar(entrenador, "partida.txt");
            agregarLog("▤ Partida guardada en partida.txt");
        } catch (IOException ex) {
            agregarLog("⚠ No se pudo guardar la partida: " + ex.getMessage());
        }
    }

    private void guardarEnRanking() {
        EntrenadorDAO dao = new EntrenadorDAO();
        boolean exito = dao.guardarResultado(entrenador.getNombre(),
                entrenador.getCriaturaActiva().getNombre(), entrenador.getVictorias());
        if (exito) {
            agregarLog("♛ Resultado enviado al ranking del salón (MySQL). Ábrelo en http://localhost:8081/ranking"
                    + " ejecutando MainRankingWeb.");
        } else {
            agregarLog("⚠ No se pudo conectar a la base de datos. Revisa ConexionBD.java y que MySQL esté corriendo.");
        }
    }

    private void actualizarEstado() {
        Criatura miCriatura = entrenador.getCriaturaActiva();
        barraJugador.setMaximum(miCriatura.getVidaMaxima());
        barraJugador.setValue(miCriatura.getVidaActual());
        etiquetaJugador.setText("<html>" + entrenador.getNombre() + " - " + textoCriatura(miCriatura) + "</html>");

        barraRival.setValue(rival.getVidaActual());
        etiquetaRival.setText("<html>Rival - " + textoCriatura(rival) + "</html>");
    }

    /** Nombre + tipo coloreado con su ícono (HTML básico que sí soporta JLabel; sin las etiquetas html/body). */
    private String textoCriatura(Criatura criatura) {
        return "<b>" + criatura.getNombre() + "</b> "
                + "<font color='" + IconosTipo.colorHex(criatura.getTipo()) + "'>"
                + IconosTipo.icono(criatura.getTipo()) + " " + criatura.getTipo() + "</font>"
                + " Nv." + criatura.getNivel() + " - HP " + criatura.getVidaActual() + "/" + criatura.getVidaMaxima();
    }

    private void agregarLog(String mensaje) {
        log.append(mensaje + "\n");
        log.setCaretPosition(log.getDocument().getLength());
    }
}
