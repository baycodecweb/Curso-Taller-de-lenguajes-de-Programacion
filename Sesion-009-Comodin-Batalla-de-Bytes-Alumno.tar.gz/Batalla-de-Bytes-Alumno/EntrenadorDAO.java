import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Sesion 7 - Conectividad a Bases de Datos con JDBC.
 * CRUD (aquí solo el "C" y el "R" que necesita el juego) sobre la
 * tabla entrenadores, usando siempre PreparedStatement.
 */
public class EntrenadorDAO {

    /**
     * Guarda el resultado del entrenador: si ya existía, solo actualiza
     * las victorias cuando el nuevo total es mayor (para no "bajar" el
     * ranking por accidente si vuelve a jugar con menos victorias).
     */
    public boolean guardarResultado(String nombre, String criaturaInicial, int victorias) {
        String sql = "INSERT INTO entrenadores (nombre, criatura_inicial, victorias) VALUES (?, ?, ?) "
                + "ON DUPLICATE KEY UPDATE victorias = GREATEST(victorias, VALUES(victorias)), "
                + "criatura_inicial = VALUES(criatura_inicial)";

        try (Connection conn = ConexionBD.obtenerConexion()) {
            if (conn == null) {
                return false;
            }
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, nombre);
                pstmt.setString(2, criaturaInicial);
                pstmt.setInt(3, victorias);
                pstmt.executeUpdate();
                return true;
            }
        } catch (SQLException e) {
            System.out.println("Error al guardar el resultado: " + e.getMessage());
            return false;
        }
    }

    /** Ranking del salón completo, de más a menos victorias. */
    public List<String[]> obtenerRanking() {
        List<String[]> ranking = new ArrayList<>();
        String sql = "SELECT nombre, criatura_inicial, victorias FROM entrenadores ORDER BY victorias DESC";

        try (Connection conn = ConexionBD.obtenerConexion()) {
            if (conn == null) {
                return ranking;
            }
            try (PreparedStatement pstmt = conn.prepareStatement(sql);
                 ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    ranking.add(new String[]{
                            rs.getString("nombre"),
                            rs.getString("criatura_inicial"),
                            String.valueOf(rs.getInt("victorias"))
                    });
                }
            }
        } catch (SQLException e) {
            System.out.println("Error al obtener el ranking: " + e.getMessage());
        }
        return ranking;
    }
}
