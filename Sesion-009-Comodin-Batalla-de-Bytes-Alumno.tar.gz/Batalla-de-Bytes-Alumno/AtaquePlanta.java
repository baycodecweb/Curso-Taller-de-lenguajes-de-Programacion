/** Ataque elemental de tipo PLANTA: fuerte contra AGUA, débil contra FUEGO. */
public class AtaquePlanta extends Ataque {

    public AtaquePlanta(String nombre, int poderBase) {
        super(nombre, poderBase);
    }

    @Override
    protected double calcularMultiplicador(TipoCriatura tipoRival) {
        if (tipoRival == TipoCriatura.AGUA) return 1.5;
        if (tipoRival == TipoCriatura.FUEGO) return 0.5;
        return 1.0;
    }
}
