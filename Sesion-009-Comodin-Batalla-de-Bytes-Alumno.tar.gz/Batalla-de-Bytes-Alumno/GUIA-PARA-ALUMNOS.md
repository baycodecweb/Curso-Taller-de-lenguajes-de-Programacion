# Guía de ejercicios — Batalla de Bytes (versión para alumnos)

Este es el mismo proyecto "Batalla de Bytes" que vimos en clase, pero con
**8 ejercicios (`// TODO`)** repartidos por el código — uno por cada
sesión del curso. La idea es que completes cada uno para demostrar que
dominas ese tema.

**El proyecto YA COMPILA y YA FUNCIONA tal cual lo recibes** (elige
Flamito, Marina o Hojaverde y juega normal). Los `TODO` son
funcionalidad nueva que falta agregar — no vas a "arreglar" nada roto,
vas a **construir** sobre lo que ya funciona.

## Cómo trabajar

1. Compila y corre el juego primero, tal cual viene, para confirmar que
   funciona (ver `README.md` para los comandos exactos).
2. Busca cada `TODO` con tu editor (o con `grep -rn "TODO" .`) y léelo
   completo: cada uno tiene pistas y te dice qué archivo mirar como
   modelo.
3. Recompila (`javac -cp "../lib/*" *.java`) después de cada cambio.
4. No necesitas hacerlos en orden, pero varios dependen uno del otro
   (marcado abajo).

## Los 8 ejercicios

| # | Sesión | Archivo(s) | Qué tienes que hacer |
|---|---|---|---|
| 1 | Swing y Eventos | `PantallaInicio.java` | Agregar un 4° botón para elegir "Rocko" (tipo TIERRA) |
| 2 | Layouts Avanzados | `PantallaBatalla.java` | Agregar un botón "Huir" y completar `huirDeBatalla()` |
| 3 | Polimorfismo/Abstractas | `AtaqueTierra.java` | Completar el multiplicador de daño del tipo TIERRA |
| 4 | UML/Constructores/`this` | `FabricaCriaturas.java`, `Criatura.java` | Completar `crearRocko()` y `ganarExperiencia(int)` |
| 5 | Archivos/Excepciones | `CriaturaDebilitadaException.java`, `GuardadoPartida.java` | Decidir dónde usar la excepción; (opcional/avanzado) guardar todo el equipo, no solo una criatura |
| 6 | SQL/MySQL | `TODO-Sesion6-historial_batallas.sql` | Diseñar la tabla `historial_batallas` |
| 7 | JDBC | `HistorialDAO.java` | Completar `guardarBatalla()` y `obtenerHistorialDe()` con `PreparedStatement` |
| 8 | Servlets | `EstadisticasServlet.java`, `MainRankingWeb.java` | Completar el servlet y registrarlo |

### Dependencias entre ejercicios

- Los ejercicios **1, 3 y 4** están conectados: los tres arman la
  criatura "Rocko" desde tres ángulos distintos (el botón, el ataque,
  la fábrica). Te recomendamos este orden: primero **3** (el ataque),
  luego **4** (`crearRocko()`), y al final **1** (el botón) — así cada
  vez que pruebes algo, lo anterior ya está listo.
- Los ejercicios **6 y 7** también están conectados: primero diseña la
  tabla SQL (6), después el `HistorialDAO` (7) que la usa.
- El ejercicio **8** depende del **7** si quieres mostrar datos reales
  de historial (aunque puedes empezar por hacer que la página cargue
  con datos de prueba y conectar la base de datos después).

## Cómo saber si te quedó bien

- **Ejercicio 1**: al abrir el juego debes ver 4 botones (Flamito,
  Marina, Hojaverde, Rocko), y poder pelear con Rocko con normalidad.
- **Ejercicio 2**: el botón "Huir" debe cerrar la ventana de batalla
  sin sumar una victoria (revisa el ranking/archivo: no debió cambiar).
- **Ejercicio 3**: Rocko debe hacer el doble de daño (x1.5) contra un
  rival de tipo FUEGO, y la mitad (x0.5) contra uno de tipo AGUA — pruébalo
  peleando varias veces y fijándote en los mensajes "¡Es muy efectivo!"
  / "No es muy efectivo..." del log.
- **Ejercicio 4**: después de ganar una batalla, la vida máxima de tu
  criatura debe subir (revisa el número "HP X/100" antes y después).
- **Ejercicio 5**: no hay una única forma "correcta" — explícale a tu
  profesor en qué parte del código decidiste lanzar la excepción y por qué.
- **Ejercicios 6-7**: ejecuta tu `CREATE TABLE`, juega una batalla, y
  verifica con una consulta `SELECT * FROM historial_batallas;` que
  quedó guardada una fila nueva.
- **Ejercicio 8**: abrir `http://localhost:8081/estadisticas` en el
  navegador debe mostrar un número (no el mensaje "TODO").

## Si te trabas

Cada `TODO` te dice qué archivo YA RESUELTO mirar como modelo — en casi
todos los casos, hay una clase hermana (`AtaqueFuego`, `EntrenadorDAO`,
`RankingServlet`, etc.) que hace exactamente lo mismo para otro caso.
Empieza copiando su estructura y después ajusta los detalles.
