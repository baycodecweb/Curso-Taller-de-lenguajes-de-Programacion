import javax.swing.SwingUtilities;

/**
 * Punto de entrada del juego de escritorio.
 * Ejecutar con:
 *   javac *.java
 *   java BatallaDeBytes
 */
public class BatallaDeBytes {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new PantallaInicio().setVisible(true));
    }
}
