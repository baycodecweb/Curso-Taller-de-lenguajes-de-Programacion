/**
 * TODO Sesión 3 (Polimorfismo / Clases Abstractas) — ¡Te toca a ti!
 *
 * Compara esta clase con AtaqueFuego.java, AtaqueAgua.java y
 * AtaquePlanta.java: las tres hacen exactamente lo mismo que tienes que
 * terminar tú aquí, solo que para otro tipo.
 *
 * Reglas que debe cumplir tu ataque de tipo TIERRA:
 *   - TIERRA es fuerte (x1.5) contra FUEGO (la tierra apaga el fuego).
 *   - TIERRA es débil (x0.5) contra AGUA (se convierte en barro).
 *   - Contra cualquier otro tipo, el multiplicador es normal (x1.0).
 *
 * Este archivo YA COMPILA tal cual está (para que el proyecto no se
 * rompa), pero el multiplicador de abajo está mal a propósito: siempre
 * devuelve 1.0. Reemplázalo por la lógica correcta.
 */
public class AtaqueTierra extends Ataque {

    public AtaqueTierra(String nombre, int poderBase) {
        super(nombre, poderBase);
    }

    @Override
    protected double calcularMultiplicador(TipoCriatura tipoRival) {
        // TODO Sesión 3: reemplaza esta línea por las reglas de arriba
        // (mira cómo lo hace AtaqueFuego.calcularMultiplicador como modelo).
        return 1.0;
    }
}
