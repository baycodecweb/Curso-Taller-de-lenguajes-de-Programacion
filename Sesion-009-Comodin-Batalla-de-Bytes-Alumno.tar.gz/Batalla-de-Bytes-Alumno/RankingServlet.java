import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Sesion 8 - Servlets y Desarrollo Web.
 * La "Pokédex" del salón: cualquiera entra desde el navegador (sin
 * instalar nada) y ve el mismo ranking que el juego de escritorio
 * guarda en MySQL a través de EntrenadorDAO.
 */
@WebServlet("/ranking")
public class RankingServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

        EntrenadorDAO dao = new EntrenadorDAO();
        List<String[]> ranking = dao.obtenerRanking();

        try (PrintWriter out = response.getWriter()) {
            out.println("<html><head><title>Batalla de Bytes - Ranking</title>");
            out.println("<style>");
            out.println("body{font-family:Arial,sans-serif;background:#0f172a;color:#e2e8f0;padding:30px;}");
            out.println("h1{color:#38bdf8;} table{border-collapse:collapse;width:100%;max-width:600px;}");
            out.println("th,td{border:1px solid #334155;padding:8px 14px;text-align:left;}");
            out.println("th{background:#1e293b;} tr:nth-child(even){background:#1a2436;}");
            out.println("</style></head><body>");
            out.println("<h1>🏆 Ranking del salón - Batalla de Bytes</h1>");

            if (ranking.isEmpty()) {
                out.println("<p>Todavía nadie ha ganado una batalla (o no hay conexión a la base de datos).</p>");
            } else {
                out.println("<table>");
                out.println("<tr><th>#</th><th>Entrenador</th><th>Criatura inicial</th><th>Victorias</th></tr>");
                int puesto = 1;
                for (String[] fila : ranking) {
                    out.println("<tr><td>" + puesto + "</td><td>" + fila[0] + "</td><td>" + fila[1]
                            + "</td><td>" + fila[2] + "</td></tr>");
                    puesto++;
                }
                out.println("</table>");
            }
            out.println("</body></html>");
        }
    }
}
