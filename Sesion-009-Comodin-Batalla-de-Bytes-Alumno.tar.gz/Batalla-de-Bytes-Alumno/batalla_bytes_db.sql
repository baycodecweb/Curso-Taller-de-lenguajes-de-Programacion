-- ============================================================
-- batalla_bytes_db.sql
-- Base de datos del proyecto "Batalla de Bytes"
-- Taller de Lenguajes de Programación - Sesión 6/7 y Proyecto Final
-- ============================================================

CREATE DATABASE IF NOT EXISTS batalla_bytes_db;
USE batalla_bytes_db;

-- Tabla de entrenadores: cada fila es el mejor resultado de un alumno del salón
CREATE TABLE IF NOT EXISTS entrenadores (
    id_entrenador INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL UNIQUE,
    criatura_inicial VARCHAR(50) NOT NULL,
    victorias INT DEFAULT 0
);

-- Datos de prueba para ver el ranking funcionando desde el primer momento
INSERT INTO entrenadores (nombre, criatura_inicial, victorias) VALUES
    ('Carlos Mendoza', 'Flamito', 5),
    ('Ana Torres', 'Marina', 3)
ON DUPLICATE KEY UPDATE victorias = VALUES(victorias);

-- Consulta de verificación: ranking del salón, de más a menos victorias
SELECT nombre, criatura_inicial, victorias
FROM entrenadores
ORDER BY victorias DESC;
