/** Ataque elemental de tipo AGUA: fuerte contra FUEGO, débil contra PLANTA. */
public class AtaqueAgua extends Ataque {

    public AtaqueAgua(String nombre, int poderBase) {
        super(nombre, poderBase);
    }

    @Override
    protected double calcularMultiplicador(TipoCriatura tipoRival) {
        if (tipoRival == TipoCriatura.FUEGO) return 1.5;
        if (tipoRival == TipoCriatura.PLANTA) return 0.5;
        return 1.0;
    }
}
