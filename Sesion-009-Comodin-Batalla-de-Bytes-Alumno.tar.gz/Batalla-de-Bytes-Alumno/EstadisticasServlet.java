import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * TODO Sesión 8 (Servlets y Desarrollo Web) — ¡Te toca a ti!
 *
 * Compara esta clase con RankingServlet.java: ese es tu modelo a
 * seguir. Esta debe mostrar una página con el TOTAL de victorias de
 * todo el salón sumadas (o el total de batallas jugadas, si ya
 * completaste el HistorialDAO de la Sesión 7).
 *
 * Este archivo YA COMPILA (para no romper el proyecto), pero doGet()
 * está sin terminar a propósito.
 *
 * No olvides registrarlo en MainRankingWeb.java (hay un TODO ahí mismo
 * que te indica dónde) para poder abrirlo en el navegador.
 */
@WebServlet("/estadisticas")
public class EstadisticasServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

        try (PrintWriter out = response.getWriter()) {
            out.println("<html><body>");
            out.println("<h1>TODO Sesión 8: completa EstadisticasServlet</h1>");
            // TODO: usa EntrenadorDAO (o tu HistorialDAO de la Sesión 7)
            // para calcular un total y mostrarlo aquí, igual que hace
            // RankingServlet con la lista del ranking.
            out.println("</body></html>");
        }
    }
}
