import org.apache.catalina.Context;
import org.apache.catalina.startup.Tomcat;

import java.io.File;

/**
 * Arranca un Tomcat embebido (sin instalar nada aparte) y registra
 * RankingServlet en /ranking. Requiere batalla_bytes_db ya creada
 * (ver batalla_bytes_db.sql) y MySQL corriendo.
 * Ejecutar con:
 *   java -cp "../lib/*:." MainRankingWeb
 */
public class MainRankingWeb {

    public static void main(String[] args) throws Exception {
        int puerto = 8081;

        Tomcat tomcat = new Tomcat();
        tomcat.setPort(puerto);
        tomcat.setBaseDir(System.getProperty("java.io.tmpdir"));

        String docBase = new File(".").getAbsolutePath();
        Context contexto = tomcat.addContext("", docBase);

        Tomcat.addServlet(contexto, "RankingServlet", new RankingServlet());
        contexto.addServletMappingDecoded("/ranking", "RankingServlet");

        // TODO Sesión 8: una vez que completes EstadisticasServlet.java,
        // descomenta estas dos líneas para poder abrir
        // http://localhost:8081/estadisticas
        // Tomcat.addServlet(contexto, "EstadisticasServlet", new EstadisticasServlet());
        // contexto.addServletMappingDecoded("/estadisticas", "EstadisticasServlet");

        tomcat.getConnector();
        tomcat.start();
        System.out.println("Servidor listo: http://localhost:" + puerto + "/ranking");
        tomcat.getServer().await();
    }
}
