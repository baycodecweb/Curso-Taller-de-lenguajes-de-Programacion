/**
 * TODO Sesión 5 (Excepción Personalizada) — ¡Te toca a ti!
 *
 * Esta clase ya está completa y compila (tiene la misma forma que
 * SinPocionesException.java) — tu ejercicio NO es esto, es decidir
 * DÓNDE usarla:
 *
 *   Busca un lugar del código donde tenga sentido impedir una acción
 *   sobre una criatura ya debilitada (0 de HP). Por ejemplo:
 *     - No dejar "usar poción" sobre una criatura debilitada.
 *     - No dejar "guardar en el ranking" a mitad de una batalla donde
 *       tu criatura activa está debilitada.
 *
 *   Sigue el mismo patrón que ya existe en Entrenador.usarPocion(),
 *   que lanza SinPocionesException, y en PantallaBatalla.usarPocion(),
 *   que la captura con try/catch y muestra el mensaje en el log.
 */
public class CriaturaDebilitadaException extends Exception {

    public CriaturaDebilitadaException(String mensaje) {
        super(mensaje);
    }
}
