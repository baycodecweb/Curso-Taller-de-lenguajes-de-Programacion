/**
 * Sesion 5 - Excepción Personalizada.
 * Se lanza cuando el entrenador intenta usar una poción sin tener ninguna.
 */
public class SinPocionesException extends Exception {

    public SinPocionesException(String mensaje) {
        super(mensaje);
    }
}
