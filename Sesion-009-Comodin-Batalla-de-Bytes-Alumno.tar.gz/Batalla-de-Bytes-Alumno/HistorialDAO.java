import java.util.ArrayList;
import java.util.List;

/**
 * TODO Sesión 7 (Conectividad a Bases de Datos con JDBC) — ¡Te toca a ti!
 *
 * Compara esta clase con EntrenadorDAO.java: ese es tu modelo a seguir,
 * solo que trabajando sobre la tabla "historial_batallas" que diseñaste
 * en el TODO de la Sesión 6 (TODO-Sesion6-historial_batallas.sql).
 *
 * Este archivo YA COMPILA tal cual está (para no romper el proyecto),
 * pero ambos métodos están sin terminar a propósito.
 */
public class HistorialDAO {

    /**
     * TODO: usa ConexionBD.obtenerConexion() + PreparedStatement para
     * insertar una fila en historial_batallas (mira
     * EntrenadorDAO.guardarResultado() como modelo: try-with-resources,
     * "?" en el SQL, pstmt.setString/setInt, pstmt.executeUpdate()).
     *
     * @return true si se guardó bien, false si hubo algún error o no
     *         hay conexión (igual que hace EntrenadorDAO).
     */
    public boolean guardarBatalla(int idEntrenador, String nombreRival, String resultado) {
        // TODO: reemplaza esto por la implementación real con JDBC
        return false;
    }

    /**
     * TODO: usa PreparedStatement + ResultSet para traer todas las filas
     * de historial_batallas de un entrenador (mira
     * EntrenadorDAO.obtenerRanking() como modelo).
     */
    public List<String[]> obtenerHistorialDe(int idEntrenador) {
        // TODO: reemplaza esto por la implementación real con JDBC
        return new ArrayList<>();
    }
}
