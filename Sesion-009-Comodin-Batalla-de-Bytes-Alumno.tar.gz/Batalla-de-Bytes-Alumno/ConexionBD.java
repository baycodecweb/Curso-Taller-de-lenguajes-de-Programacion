import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexionBD {
    // Mismos parámetros de conexión que en codigo3/ConexionBD.java (misma sesión 7),
    // apuntando a la base de datos propia de este proyecto.
    private static final String URL = "jdbc:mysql://localhost:3306/batalla_bytes_db?useSSL=false&serverTimezone=UTC";
    private static final String USUARIO = "root";
    private static final String PASSWORD = "ZRJiul+jR+rPUC5RGDeso3v1"; // Cambiar según la configuración local

    public static Connection obtenerConexion() {
        Connection conexion = null;
        try {
            conexion = DriverManager.getConnection(URL, USUARIO, PASSWORD);
        } catch (SQLException e) {
            System.out.println("Error al conectar con la base de datos: " + e.getMessage());
        }
        return conexion;
    }
}
