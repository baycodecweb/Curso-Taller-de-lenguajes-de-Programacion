/**
 * Punto único donde se arman las 3 criaturas iniciales del juego,
 * cada una con sus 4 ataques (2 elementales propios + 2 neutrales
 * compartidos por todas). Evita repetir esta lista en cada pantalla.
 */
public class FabricaCriaturas {

    public static Criatura crearFlamito() {
        return new Criatura("Flamito", TipoCriatura.FUEGO, 100, 1, new Ataque[]{
                new AtaqueFuego("Llamarada", 18),
                new AtaqueFuego("Explosión Ígnea", 25),
                new AtaqueNeutral("Golpe Normal", 12),
                new AtaqueNeutral("Impacto Certero", 15)
        });
    }

    public static Criatura crearMarina() {
        return new Criatura("Marina", TipoCriatura.AGUA, 100, 1, new Ataque[]{
                new AtaqueAgua("Chorro de Agua", 18),
                new AtaqueAgua("Maremoto", 25),
                new AtaqueNeutral("Golpe Normal", 12),
                new AtaqueNeutral("Impacto Certero", 15)
        });
    }

    public static Criatura crearHojaverde() {
        return new Criatura("Hojaverde", TipoCriatura.PLANTA, 100, 1, new Ataque[]{
                new AtaquePlanta("Látigo Cepa", 18),
                new AtaquePlanta("Fotosíntesis Feroz", 25),
                new AtaqueNeutral("Golpe Normal", 12),
                new AtaqueNeutral("Impacto Certero", 15)
        });
    }

    /**
     * TODO Sesión 4 (UML, Constructores y "this") — ¡Te toca a ti!
     *
     * Construye y devuelve la criatura "Rocko": tipo TIERRA, vida máxima
     * 100, nivel 1, con 4 ataques (copia exactamente el patrón de
     * crearFlamito()/crearMarina()/crearHojaverde() de arriba):
     *   - 2 ataques propios usando AtaqueTierra (el que completaste en
     *     el TODO de la Sesión 3 — no funcionará bien hasta que lo termines)
     *   - 2 ataques neutrales usando AtaqueNeutral, iguales a los de las
     *     demás criaturas ("Golpe Normal" 12 y "Impacto Certero" 15)
     */
    public static Criatura crearRocko() {
        throw new UnsupportedOperationException("TODO Sesión 4: completa crearRocko()");
    }

    /** Devuelve una copia "fresca" (vida al máximo) de la criatura elegida, por nombre. */
    public static Criatura crearPorNombre(String nombre) {
        switch (nombre) {
            case "Flamito": return crearFlamito();
            case "Marina": return crearMarina();
            case "Hojaverde": return crearHojaverde();
            case "Rocko": return crearRocko();
            default: throw new IllegalArgumentException("Criatura desconocida: " + nombre);
        }
    }
}
