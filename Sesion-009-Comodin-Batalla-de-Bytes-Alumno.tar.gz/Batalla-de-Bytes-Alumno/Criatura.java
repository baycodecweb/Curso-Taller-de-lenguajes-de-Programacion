/**
 * Sesion 4 - Diagramas UML, Constructores y la Referencia "this".
 *
 * Diagrama de clase (UML) de referencia:
 * ┌───────────────────────────────┐
 * │            Criatura           │
 * ├───────────────────────────────┤
 * │ - nombre: String               │
 * │ - tipo: TipoCriatura           │
 * │ - vidaMaxima: int              │
 * │ - vidaActual: int              │
 * │ - nivel: int                   │
 * │ - ataques: Ataque[4]           │
 * ├───────────────────────────────┤
 * │ + Criatura(nombre, tipo, ...)  │
 * │ + recibirDanio(int): void      │
 * │ + curar(int): void             │
 * │ + estaDebilitada(): boolean    │
 * └───────────────────────────────┘
 */
public class Criatura {

    private final String nombre;
    private final TipoCriatura tipo;
    private int vidaMaxima; // TODO Sesión 4: ya no es "final" porque subirá al subir de nivel
    private int vidaActual;
    private int nivel;
    private final Ataque[] ataques;
    private int experiencia; // TODO Sesión 4: úsala en ganarExperiencia() de abajo

    public Criatura(String nombre, TipoCriatura tipo, int vidaMaxima, int nivel, Ataque[] ataques) {
        // "this" distingue el atributo del objeto del parámetro que llega
        // "de afuera" con el mismo nombre (igual que en la Sesión 4 del curso).
        this.nombre = nombre;
        this.tipo = tipo;
        this.vidaMaxima = vidaMaxima;
        this.vidaActual = vidaMaxima;
        this.nivel = nivel;
        this.ataques = ataques;
    }

    public void recibirDanio(int danio) {
        vidaActual -= danio;
        if (vidaActual < 0) {
            vidaActual = 0;
        }
    }

    public void curar(int cantidad) {
        vidaActual += cantidad;
        if (vidaActual > vidaMaxima) {
            vidaActual = vidaMaxima;
        }
    }

    public boolean estaDebilitada() {
        return vidaActual <= 0;
    }

    /**
     * TODO Sesión 4 (UML, Constructores y "this") — ¡Te toca a ti!
     *
     * Debe sumar "cantidad" a experiencia, y si experiencia llega a 100
     * (o más), la criatura sube de nivel:
     *   - nivel aumenta en 1
     *   - vidaMaxima aumenta en 20
     *   - vidaActual también aumenta en 20 (para que se note al instante)
     *   - experiencia vuelve a 0 (o le restas 100, como prefieras)
     *
     * Pista: usa "this.experiencia" si nombras el parámetro igual que el
     * atributo, tal como se explica en el comentario del constructor de
     * arriba.
     */
    public void ganarExperiencia(int cantidad) {
        // TODO: implementa la lógica de arriba (por ahora no hace nada)
    }

    public String getNombre() {
        return nombre;
    }

    public TipoCriatura getTipo() {
        return tipo;
    }

    public int getVidaMaxima() {
        return vidaMaxima;
    }

    public int getVidaActual() {
        return vidaActual;
    }

    public int getNivel() {
        return nivel;
    }

    public Ataque[] getAtaques() {
        return ataques;
    }

    @Override
    public String toString() {
        return nombre + " (" + tipo + ") Nv." + nivel + " - HP " + vidaActual + "/" + vidaMaxima;
    }
}
