import java.awt.Color;

/**
 * Íconos y colores por tipo de criatura, para que las pantallas se vean
 * más vistosas y coloridas (pensado para que un niño identifique el tipo
 * de un vistazo, sin tener que leer la palabra "FUEGO"/"AGUA"/"PLANTA").
 *
 * Nota: los emoji "a color" (🔥💧🌿) no se pueden dibujar en Swing en este
 * equipo (Java no sabe pintar fuentes de emoji a color como Noto Color
 * Emoji). Por eso se usan símbolos Unicode simples, que sí se ven bien
 * con cualquier fuente del sistema.
 */
public class IconosTipo {

    public static String icono(TipoCriatura tipo) {
        switch (tipo) {
            case FUEGO: return "♨";
            case AGUA: return "≈";
            case PLANTA: return "☘";
            case TIERRA: return "◆";
            default: return "";
        }
    }

    public static Color color(TipoCriatura tipo) {
        switch (tipo) {
            case FUEGO: return new Color(234, 88, 12);
            case AGUA: return new Color(2, 132, 199);
            case PLANTA: return new Color(22, 163, 74);
            case TIERRA: return new Color(120, 83, 40);
            default: return Color.DARK_GRAY;
        }
    }

    public static String colorHex(TipoCriatura tipo) {
        Color c = color(tipo);
        return String.format("#%02x%02x%02x", c.getRed(), c.getGreen(), c.getBlue());
    }
}
