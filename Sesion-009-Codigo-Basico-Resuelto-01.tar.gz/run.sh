#!/bin/bash
set -e
cd "$(dirname "$0")"
java -cp out Main
