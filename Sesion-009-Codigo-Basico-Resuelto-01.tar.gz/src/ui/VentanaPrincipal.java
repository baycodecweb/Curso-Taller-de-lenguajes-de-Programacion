package ui;

import core.Cuarentena;
import core.Escaneador;
import core.Resultado;
import database.BaseFirmas;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import java.awt.BorderLayout;
import java.awt.Font;
import java.nio.file.Path;

public class VentanaPrincipal extends JFrame {

    private final JTextArea areaResultado = new JTextArea();
    private final JLabel etiquetaEstado = new JLabel("Listo");
    private final Escaneador escaneador;

    public VentanaPrincipal() {
        super("Antivirus Java - MVP");

        Path raizProyecto = Path.of(System.getProperty("user.dir"));
        BaseFirmas baseFirmas = new BaseFirmas(raizProyecto.resolve("firmas.db"));
        Cuarentena cuarentena = new Cuarentena(raizProyecto.resolve("cuarentena"));
        this.escaneador = new Escaneador(baseFirmas, cuarentena);

        construirInterfaz();

        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void construirInterfaz() {
        setLayout(new BorderLayout());

        JPanel panelSuperior = new JPanel();
        JButton botonEscanear = new JButton("Seleccionar y escanear...");
        botonEscanear.addActionListener(e -> iniciarEscaneoManual());
        panelSuperior.add(botonEscanear);
        panelSuperior.add(etiquetaEstado);

        areaResultado.setEditable(false);
        areaResultado.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));

        add(panelSuperior, BorderLayout.NORTH);
        add(new JScrollPane(areaResultado), BorderLayout.CENTER);
    }

    public void iniciarEscaneoManual() {
        JFileChooser selector = new JFileChooser();
        selector.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
        int seleccion = selector.showOpenDialog(this);
        if (seleccion != JFileChooser.APPROVE_OPTION) {
            return;
        }
        Path ruta = selector.getSelectedFile().toPath();
        mostrarEstado("Escaneando...");
        Resultado resultado = escaneador.analizarCarpeta(ruta);
        mostrarResultado(resultado);
        mostrarEstado("Listo");
    }

    public void mostrarEstado(String estado) {
        etiquetaEstado.setText(estado);
    }

    public void mostrarResultado(Resultado resultado) {
        areaResultado.setText(resultado.toString());
    }
}
