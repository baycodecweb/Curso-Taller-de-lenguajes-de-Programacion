import org.apache.catalina.Context;
import org.apache.catalina.startup.Tomcat;

import java.io.File;

/**
 * Arranca un Tomcat embebido (sin instalar nada aparte) y registra
 * SaborEscolarLoginServletIntegrado en /login. Requiere sabor_escolar_db
 * ya creada (ver sabor_escolar_db.sql) y MySQL/MariaDB corriendo.
 * Ejecutar con:
 *   java -cp "../lib/*:." MainSaborEscolarIntegrado
 */
public class MainSaborEscolarIntegrado {

    public static void main(String[] args) throws Exception {
        int puerto = 8080;

        Tomcat tomcat = new Tomcat();
        tomcat.setPort(puerto);
        tomcat.setBaseDir(System.getProperty("java.io.tmpdir"));

        String docBase = new File(".").getAbsolutePath();
        Context contexto = tomcat.addContext("", docBase);

        Tomcat.addServlet(contexto, "SaborEscolarLoginServletIntegrado", new SaborEscolarLoginServletIntegrado());
        contexto.addServletMappingDecoded("/login", "SaborEscolarLoginServletIntegrado");

        tomcat.getConnector();
        tomcat.start();
        System.out.println("Servidor listo: http://localhost:" + puerto + "/login");
        tomcat.getServer().await();
    }
}
