import org.apache.catalina.Context;
import org.apache.catalina.startup.Tomcat;

import java.io.File;

/**
 * Arranca un Tomcat embebido (sin instalar nada aparte) y registra
 * GameStoreLoginServletIntegrado en /login. Requiere gamestore_db
 * ya creada (ver gamestore_db.sql) y MySQL/MariaDB corriendo.
 * Ejecutar con:
 *   java -cp "../lib/*:." MainGameStoreIntegrado
 */
public class MainGameStoreIntegrado {

    public static void main(String[] args) throws Exception {
        int puerto = 8080;

        Tomcat tomcat = new Tomcat();
        tomcat.setPort(puerto);
        tomcat.setBaseDir(System.getProperty("java.io.tmpdir"));

        String docBase = new File(".").getAbsolutePath();
        Context contexto = tomcat.addContext("", docBase);

        Tomcat.addServlet(contexto, "GameStoreLoginServletIntegrado", new GameStoreLoginServletIntegrado());
        contexto.addServletMappingDecoded("/login", "GameStoreLoginServletIntegrado");

        tomcat.getConnector();
        tomcat.start();
        System.out.println("Servidor listo: http://localhost:" + puerto + "/login");
        tomcat.getServer().await();
    }
}
