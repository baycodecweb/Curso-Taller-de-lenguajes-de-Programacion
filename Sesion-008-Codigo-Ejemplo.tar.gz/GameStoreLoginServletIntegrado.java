import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/login")
public class GameStoreLoginServletIntegrado extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            out.println("<html><body>");
            out.println("<h2>GameStore Escolar - Acceso Web (con Base de Datos)</h2>");
            out.println("<form method='post' action='login'>");
            out.println("Usuario: <input type='text' name='usuario'><br>");
            out.println("<input type='submit' value='Ingresar'>");
            out.println("</form>");
            out.println("</body></html>");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String usuario = request.getParameter("usuario");
        response.setContentType("text/html;charset=UTF-8");

        try (PrintWriter out = response.getWriter()) {
            out.println("<html><body>");
            if (usuario == null || usuario.trim().isEmpty()) {
                out.println("<h2>Error: ingrese un usuario</h2>");
            } else if (!conexionDisponible()) {
                out.println("<h2>Error: no se pudo conectar a la base de datos</h2>");
                out.println("<p>Revisa ConexionBD.java (URL, usuario, contraseña) y que MySQL/MariaDB esté corriendo.</p>");
            } else if (validarUsuarioEnBD(usuario)) {
                out.println("<h2>Bienvenido, " + usuario + "</h2>");
            } else {
                out.println("<h2>Error: usuario no encontrado en la base de datos</h2>");
            }
            out.println("</body></html>");
        }
    }

    // Prueba rápida de conexión, para poder distinguir "sin conexión" de "usuario no encontrado"
    private boolean conexionDisponible() {
        try (Connection conn = ConexionBD.obtenerConexion()) {
            return conn != null;
        } catch (SQLException e) {
            return false;
        }
    }

    // Igual que en el Proyecto Final (GameStoreLoginIntegrado.java), pero desde un Servlet
    private boolean validarUsuarioEnBD(String nombre) {
        boolean existe = false;
        String sql = "SELECT * FROM estudiantes WHERE nombre = ?";

        try (Connection conn = ConexionBD.obtenerConexion()) {
            if (conn == null) {
                return false;
            }
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, nombre);
                try (ResultSet rs = pstmt.executeQuery()) {
                    if (rs.next()) {
                        existe = true;
                    }
                }
            }
        } catch (SQLException e) {
            System.out.println("Error al validar usuario: " + e.getMessage());
        }
        return existe;
    }
}
