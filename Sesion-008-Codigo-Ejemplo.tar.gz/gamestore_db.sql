-- ============================================================
-- gamestore_db.sql
-- Script de la base de datos del proyecto "GameStore Escolar"
-- Taller de Lenguajes de Programación - Sesion 6/7 y Proyecto Final
-- ============================================================

-- Creación de la base de datos
CREATE DATABASE IF NOT EXISTS gamestore_db;
USE gamestore_db;

-- Tabla Estudiantes
CREATE TABLE estudiantes (
    id_estudiante INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    puntos INT DEFAULT 0
);

-- Tabla Recompensas
CREATE TABLE recompensas (
    id_recompensa INT AUTO_INCREMENT PRIMARY KEY,
    nombre_item VARCHAR(100) NOT NULL,
    costo_puntos INT NOT NULL
);

-- Tabla Historial de Canjes, con llaves foráneas hacia las dos tablas anteriores
CREATE TABLE historial_canjes (
    id_canje INT AUTO_INCREMENT PRIMARY KEY,
    id_estudiante INT,
    id_recompensa INT,
    fecha_canje TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_estudiante) REFERENCES estudiantes(id_estudiante),
    FOREIGN KEY (id_recompensa) REFERENCES recompensas(id_recompensa)
);

-- Datos de prueba
INSERT INTO estudiantes (nombre, puntos) VALUES
    ('Carlos Mendoza', 500),
    ('Ana Torres', 350);

INSERT INTO recompensas (nombre_item, costo_puntos) VALUES
    ('Skin Guerrero Cyber', 150),
    ('Pase de Prórroga', 300);

-- Registro de un canje relacionando estudiante y recompensa
INSERT INTO historial_canjes (id_estudiante, id_recompensa) VALUES (1, 1);

-- Consulta de verificación: historial detallado con JOIN
SELECT h.id_canje, e.nombre AS estudiante, r.nombre_item, r.costo_puntos, h.fecha_canje
FROM historial_canjes h
JOIN estudiantes e ON h.id_estudiante = e.id_estudiante
JOIN recompensas r ON h.id_recompensa = r.id_recompensa;
